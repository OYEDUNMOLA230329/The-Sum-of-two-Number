
package sum.of.two.numbers;
 import java.util.Scanner;

public class SumOfTwoNumbers {
   public static void main(String[] args) {
       //Create a Scanner object to read user input
       Scanner scanner = new Scanner(System.in);
       //Prompt the user to enter the first number
       System.out.println("Enter first number:");
       double num1 =scanner.nextDouble();
       
       //Prompt the user to entr the secound number
       System.out.println("Enter secound number:");
       double num2 = scanner.nextDouble();
              //Calculate the reult 
       double sum =num1 + num2;
       double average = (num1 + num2)/2;
       double product = num1 * num2;
       double difference = (num1 - num2);
              //Diplay the reult
       System.out.println("The sum is :" +sum);
       System.out.println("The product is:" + product);
        System.out.println("The average is:" + average);
        System.out.println("The difference is:" + difference);

       //Cloe the scanner
       scanner.close();
   }
}